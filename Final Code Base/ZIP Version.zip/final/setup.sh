#!/bin/bash

DYLD_LIBRARY_PATH=/Applications/MATLAB.app/bin/maci64:/Applications/MATLAB.app/sys/os/maci64:$DYLD_LIBRARY_PATH
export DYLD_LIBRARY_PATH
PATH=$PATH:/Applications/MATLAB.app/bin/
export PATH
